import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class validateSite {
   static WebDriver driver = null;
     static JavascriptExecutor js =null;

    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","C:\\Users\\pkhurana\\Downloads\\chromedriver_win32\\chromedriver.exe");

       testCaseOne();
       testCaseThree();
       testCaseFour();
       testCaseTwo();

    }

    private static void testCaseOne() throws InterruptedException {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        driver.get("https://jupiter.cloud.planittesting.com/#/");
        driver.manage().window().maximize();

        WebElement contactPage = driver.findElement(By.linkText("Contact"));
        contactPage.click();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(5000);

        WebElement submitButton = driver.findElement(By.linkText("Submit"));
        submitButton.click();
        JavascriptExecutor js1 = (JavascriptExecutor) driver;
        js1.executeScript("window.scrollTo(document.body.scrollHeight,0)");
        Thread.sleep(5000);

        WebElement firstName = driver.findElement(By.id("forename"));
        WebElement firstNameError = driver.findElement(By.id("forename-err"));
        String firstNameErrorMsg = firstNameError.getText();
        Assert.assertEquals(firstNameErrorMsg, "Forename is required");

        WebElement email = driver.findElement(By.id("email"));
        WebElement emailError = driver.findElement(By.id("email-err"));
        String emailErrorMsg = emailError.getText();
        Assert.assertEquals(emailErrorMsg, "Email is required");

        WebElement message = driver.findElement(By.id("message"));
        WebElement messageError = driver.findElement(By.id("message-err"));
        String messageErrorMsg = messageError.getText();
        Assert.assertEquals(messageErrorMsg, "Message is required");

        firstName.sendKeys("John");
        Assert.assertTrue(driver.findElements(By.id("forename-err")).isEmpty());
        email.sendKeys("john.example@example.com");
        Assert.assertTrue(driver.findElements(By.id("email-err")).isEmpty());
        message.sendKeys("Validating functionality of the page");
        Assert.assertTrue(driver.findElements(By.id("message-err")).isEmpty());
        System.out.println("Test Case 1 is successful");
        driver.close();

 }

    private static void testCaseTwo() throws InterruptedException {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        driver.get("https://jupiter.cloud.planittesting.com/#/");
        driver.manage().window().maximize();

        WebElement contactPage = driver.findElement(By.linkText("Contact"));
        contactPage.click();
        Thread.sleep(6000);

        for (int i=0; i<5;i++) {
            Thread.sleep(6000);
            WebElement firstName = driver.findElement(By.id("forename"));
            WebElement email = driver.findElement(By.id("email"));
            WebElement message = driver.findElement(By.id("message"));
            WebElement submitButton = driver.findElement(By.linkText("Submit"));
            firstName.click();
            firstName.sendKeys("John");
            email.click();
            email.sendKeys("john.example@example.com");
            message.click();
            message.sendKeys("Validating functionality of the page");
            submitButton.click();
            Thread.sleep(6000);
            WebElement backButton = driver.findElement(By.partialLinkText("Back"));
            backButton.click();
        }
        System.out.println("Test Case 2 is successful");
        driver.close();

    }

    private static void testCaseThree() throws InterruptedException {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        driver.get("https://jupiter.cloud.planittesting.com/#/");
        driver.manage().window().maximize();
        WebElement shopPage = driver.findElement(By.linkText("Shop"));
        shopPage.click();
        Thread.sleep(5000);
        Actions action = new Actions(driver);

        WebElement shopBunny = driver.findElement(By.xpath("/html/body/div[2]/div/ul/li[4]/div/p/a"));
        action.moveToElement(shopBunny).perform();
        shopBunny.click();
        WebElement shopCow = driver.findElement(By.xpath("/html/body/div[2]/div/ul/li[6]/div/p/a"));
        action.moveToElement(shopCow).perform();
        shopCow.click();
        shopCow.click();

        WebElement cart = driver.findElement(By.id("nav-cart"));
        cart.click();
        Thread.sleep(5000);

        String bunnyCount = driver.findElement(By.xpath(" /html/body/div[2]/div/form/table/tbody/tr[1]/td[3]/input")).getAttribute("value");
        String cowCount = driver.findElement(By.xpath(" /html/body/div/div/form/table/tbody/tr[2]/td[3]/input")).getAttribute("value");
        Assert.assertEquals(bunnyCount,"1");
        Assert.assertEquals(cowCount.substring(0),"2");
        System.out.println("Test Case 3 is successful");
        driver.close();

    }

    private static void testCaseFour() throws InterruptedException {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
        driver.get("https://jupiter.cloud.planittesting.com/#/");
        driver.manage().window().maximize();
        WebElement shopPage = driver.findElement(By.linkText("Shop"));
        shopPage.click();
        Thread.sleep(5000);
        Actions action = new Actions(driver);

        WebElement shopBunny = driver.findElement(By.xpath("/html/body/div[2]/div/ul/li[4]/div/p/a"));
        action.moveToElement(shopBunny).perform();
        for(int i=0;i<5;i++) {
            shopBunny.click();
        }

        WebElement shopFrog = driver.findElement(By.xpath("/html/body/div[2]/div/ul/li[2]/div/p/a"));
        action.moveToElement(shopFrog).perform();
        for(int i=0;i<2;i++) {
            shopFrog.click();
        }
        WebElement shopvBear = driver.findElement(By.xpath("/html/body/div[2]/div/ul/li[7]/div/p/a"));
        action.moveToElement(shopvBear).perform();
        for(int i=0;i<3;i++) {
            shopvBear.click();
        }

        WebElement cart = driver.findElement(By.id("nav-cart"));
        cart.click();
        Thread.sleep(5000);

        String priceBunny = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[1]/td[2]")).getText().substring(1,5);
        String priceFrog = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[2]/td[2]")).getText().substring(1,6);
        String priceBear = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[3]/td[2]")).getText().substring(1,6);

        String bunnyCount = driver.findElement(By.xpath(" /html/body/div[2]/div/form/table/tbody/tr[1]/td[3]/input")).getAttribute("value");
        String frogCount = driver.findElement(By.xpath(" /html/body/div[2]/div/form/table/tbody/tr[2]/td[3]/input")).getAttribute("value");
        String bearCount = driver.findElement(By.xpath(" /html/body/div[2]/div/form/table/tbody/tr[3]/td[3]/input")).getAttribute("value");

        String tpriceBunny = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[1]/td[4]")).getText().substring(1,5);
        String tpriceFrog = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[2]/td[4]")).getText().substring(1,5);
        String tpriceBear = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[3]/td[4]")).getText().substring(1,5);

        Assert.assertEquals(String.valueOf(Float.parseFloat(priceBunny)*Float.parseFloat(bunnyCount)).substring(0,4),tpriceBunny);
        Assert.assertEquals(String.valueOf(Float.parseFloat(priceFrog)*Float.parseFloat(frogCount)).substring(0,4),tpriceFrog);
        Assert.assertEquals(String.valueOf(Float.parseFloat(priceBear)*Float.parseFloat(bearCount)).substring(0,4),tpriceBear);

        String priceTotal = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tfoot/tr[1]/td/strong")).getText().substring(7,10);
        Assert.assertEquals(String.valueOf(Float.parseFloat(tpriceBunny)+Float.parseFloat(tpriceFrog)+Float.parseFloat(tpriceBear)).substring(0,3),priceTotal);
        System.out.println("Test Case 4 is successful");
        driver.close();
    }
}
